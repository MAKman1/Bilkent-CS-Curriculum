import java.awt.*;
import javax.swing.JComponent;
public interface Drawable{
   void draw( Graphics g);
}