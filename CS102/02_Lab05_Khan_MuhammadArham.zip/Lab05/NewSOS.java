import cs101.sosgame.SOS;
import java.lang.reflect.Method;

public class NewSOS extends SOS
{
   public NewSOS( int dimensions)
   {
      super( dimensions);
   }
   
   public void changeTurn()
   {
   }
}
