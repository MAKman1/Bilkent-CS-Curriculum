public class TestCurrency
{
   public static void main( String[] args)
   {
      CurrencyList list;
      list = new CurrencyList();
      
      System.out.println(list.toString());
   }
}