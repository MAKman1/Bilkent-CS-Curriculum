import cs1.SimpleURLReader;
//test class
public class TestSimpleURLReader
{
   
   public static void main( String[] args)
   {
      /*
      MySimpleURLReader test = new MySimpleURLReader( "http://www.cs.bilkent.edu.tr/~david/housman.txt");
      System.out.println(test.getPageContents());
      System.out.println(test.getLineCount());
      */
      /*
      HTMLFilteredReader test = new HTMLFilteredReader( "http://www.cs.bilkent.edu.tr/~david/index.html");
      System.out.println(test.getPageContents());
      System.out.println(test.getLineCount());
      */
      /*
      SuperHTMLFilteredReader test = new SuperHTMLFilteredReader( "http://www.cs.bilkent.edu.tr/~david/index.html");
      System.out.println(test.getLinks());
      System.out.println(test.getOverhead());
      */
      
   }
   
   

}