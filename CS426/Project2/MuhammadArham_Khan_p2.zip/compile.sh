gcc serial_bfs.c -o serial_bfs
mpicc parallel_bfs.c -o parallel_bfs